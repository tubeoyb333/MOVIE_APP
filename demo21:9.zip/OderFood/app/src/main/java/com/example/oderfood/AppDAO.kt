package com.example.oderfood

import androidx.room.*
import com.example.oderfood.data.Food
import com.example.oderfood.data.Kind

@Dao
interface AppDAO {
    @Query("SELECT * FROM tb_food")
    fun getFoodList(): List<Food>?

    @Insert
    fun insertFood(food: Food)

    @Query("UPDATE tb_food SET isFavorite = :isFavorite WHERE id = :id")
    fun updateFavoriteFood(id: Int, isFavorite: Boolean)

    @Insert
    fun insertFoodList(list: List<Food>)

    @Query("SELECT * FROM tb_food WHERE isFavorite = 1")
    fun getFavoriteFoodList(): List<Food>?

    @Query("DELETE FROM tb_food WHERE id = :id")
    fun deleteFood(id: Int)

    @Query("SELECT * FROM tb_kind")
    fun getKind(): List<Kind>?

    @Insert
    fun insertKind(kind: Kind)

    @Insert
    fun insertKind(list: List<Kind>)
}