package com.example.recyclerview

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.example.oderfood.R
import com.example.oderfood.data.Food

class FoodAdapter: ListAdapter<Food,FoodAdapter.FoodViewHolder>(FoodUtil()) {
    var onItemClick: (Food)-> Unit={
    }
    var onClickDelete: (Food, Int) -> Unit = { Food, Int->
    }
    var onClickFavorite: (Food, Int) -> Unit = { a,b ->

    }
    inner class FoodViewHolder(view: View):RecyclerView.ViewHolder(view){
        val btnDelete = view.findViewById<Button>(R.id.btnDeleteView)
        val imgFavorite = view.findViewById<ImageView>(R.id.imgFavorite)
        init {
            btnDelete.setOnClickListener {
                onClickDelete.invoke(currentList[layoutPosition],layoutPosition)
            }
            view.rootView.setOnClickListener {
                onItemClick.invoke(currentList[layoutPosition])
            }
            imgFavorite.setOnClickListener {
                onClickFavorite.invoke(currentList[layoutPosition],layoutPosition)
            }
        }
        val tvFoodName = view.findViewById<TextView>(R.id.tvFoodName)
        val tvFoodPrice = view.findViewById<TextView>(R.id.tvFoodPrice)
        val imgFood = view.findViewById<ImageView>(R.id.imgFood)

        fun onBind(food: Food){
            tvFoodName.text = food.name
            tvFoodPrice.text = food.price
            food.img?.let { imgFood.setImageResource(it) }
            if (food.isFavorite){
                imgFavorite.setImageResource(R.drawable.baseline_favorite_24)
            } else {
                imgFavorite.setImageResource(R.drawable.baseline_favorite_border_24)
            }
        }
    }
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): FoodViewHolder {

        val inflater = LayoutInflater.from(parent.context)
        val view = inflater.inflate(R.layout.item_food,parent,false)
        return  FoodViewHolder(view)

    }
    override fun getItemCount(): Int {
        return currentList.size
    }
    override fun onBindViewHolder(holder: FoodViewHolder, position: Int) {
        holder.onBind(currentList[position])
    }
}
class FoodUtil:androidx.recyclerview.widget.DiffUtil.ItemCallback<Food>(){
    override fun areItemsTheSame(oldItem: Food, newItem: Food): Boolean {
        return newItem.id == oldItem.id && newItem.isFavorite == oldItem.isFavorite
    }
    override fun areContentsTheSame(oldItem: Food, newItem: Food): Boolean {
        return newItem.id == oldItem.id && newItem.isFavorite == oldItem.isFavorite
    }

}