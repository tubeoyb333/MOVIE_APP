package com.example.oderfood.data


import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity (tableName = "tb_food")
data class Food(
    @PrimaryKey (autoGenerate = true) val id: Int,
    val kind: String?,
    val name:String?,
    val price:String?,
    val img:Int?,
    val isFavorite: Boolean,
): java.io.Serializable