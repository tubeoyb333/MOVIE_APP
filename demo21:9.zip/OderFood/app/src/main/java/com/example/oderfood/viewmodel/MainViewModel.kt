package com.example.oderfood.viewmodel

import android.content.Context
import android.util.Log
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.room.Room
import com.example.oderfood.AppDAO
import com.example.oderfood.R
import com.example.oderfood.data.Food
import com.example.oderfood.data.Kind
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainViewModel(private val appDAO: AppDAO) : ViewModel() {
    val foodList: MutableLiveData<List<Food>?> = MutableLiveData()
    val kindList: MutableLiveData<List<Kind>?> = MutableLiveData()
    var currentList: MutableList<Food> = mutableListOf()
    var list: MutableList<Food> = mutableListOf(
        Food(1, "Veggie", "Veggie tomato mix", "N1,900", R.drawable.img,false),
        Food(2, "Egg", "Egg and cucmber...", "N1,900", R.drawable.img_2,false),
        Food(3, "Fried", "Fried chicken m.", "N1,900", R.drawable.img_3,false)
    )
    val listKind: List<Kind> = listOf(
        Kind(kindFood = "All"),
        Kind(kindFood = "Veggie"),
        Kind(kindFood = "Fried"),
        Kind(kindFood = "Egg"),
        Kind(kindFood = "Moi")
    )

    fun insertFoodList() {
        viewModelScope.launch(Dispatchers.IO) {
            appDAO.insertFoodList(list)
            withContext(Dispatchers.Main){
                getFoodList()
            }
        }
    }

    fun getFoodList() {
        viewModelScope.launch(Dispatchers.IO) {
            val list = appDAO.getFoodList()
            withContext(Dispatchers.Main){
                foodList.value = list
                Log.d("AAA",list.toString())
            }
        }
    }
    fun getFavoriteFoodList() {
        viewModelScope.launch(Dispatchers.IO) {
            val list = appDAO.getFavoriteFoodList()
            Log.d("ZZZ",list.toString())
        }
    }

    fun insertKindList(){
        viewModelScope.launch(Dispatchers.IO) {
            appDAO.insertKind(listKind)
            withContext(Dispatchers.Main){
                getKindList()
            }
        }
    }

    fun getKindList() {
        viewModelScope.launch(Dispatchers.IO) {
            val listKind = appDAO.getKind()
            withContext(Dispatchers.Main){
                kindList.value = listKind
            }
        }
    }
    fun fetchListByKind(kind: Kind) {
        currentList = mutableListOf()
        if (kind.kindFood == "All") {
            currentList.addAll(list)
        } else {
            currentList.addAll(list.filter { it.kind == kind.kindFood })
        }
        foodList.value = currentList
    }
    fun updateFood(id: Int,favorite: Boolean) {
        viewModelScope.launch(Dispatchers.IO){
            appDAO.updateFavoriteFood(id,favorite)
            withContext(Dispatchers.Main){
                getFoodList()
            }
        }

    }


//    fun fetchKind() {
//        kindList.value = listKind
//    }
    //    fun fetchList() {
//        currentList = list
//        foodList.value = list
//    }
//
}
