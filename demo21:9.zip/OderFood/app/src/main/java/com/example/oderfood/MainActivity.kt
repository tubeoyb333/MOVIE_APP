package com.example.oderfood

import android.annotation.SuppressLint
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import androidx.room.Room
import com.example.recyclerview.FoodAdapter
import com.example.oderfood.adapter.KindAdapter
import com.example.oderfood.data.Food
import com.example.oderfood.viewmodel.MainViewModel

class MainActivity : AppCompatActivity() {
    @SuppressLint("MissingInflatedId", "SetTextI18n")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val recyclerView: RecyclerView = findViewById(R.id.rcvFood)
        val recyclerViewKind: RecyclerView = findViewById(R.id.rcvKind)
        val tvFoundResults = findViewById<TextView>(R.id.tvFoundResults)
        val btnDelete = findViewById<Button>(R.id.btnDeleteView)
        val foodAdapter = FoodAdapter()
        val db = Room.databaseBuilder(
            // đối tượng mà có thể sử dụng chuy cập tài nguyên và chức năng hệ thống của ứng dụng của bạn
            applicationContext,
            AppDatabase::class.java, "database-name"
        ).build()
        val appDAO: AppDAO = db.appDao()
        val mainViewModel = MainViewModel(appDAO)
        // Quan sát dữ liệu foodList ở viewModel
        recyclerView.adapter = foodAdapter
        foodAdapter.onClickFavorite = { food, i ->
            mainViewModel.updateFood(food.id,!food.isFavorite)
        }
        mainViewModel.getFoodList()
        mainViewModel.getFavoriteFoodList()
        mainViewModel.foodList.observe(this) {
            if (it.isNullOrEmpty()) {
                mainViewModel.insertFoodList()
            } else {
                foodAdapter.submitList(it)
            }
        }
        mainViewModel.getKindList()
        mainViewModel.kindList.observe(this){
            val kindAdapter = KindAdapter(it)
            recyclerViewKind.adapter = kindAdapter
            if (it.isNullOrEmpty()){
                mainViewModel.insertKindList()
            } else {
                kindAdapter.onItemClickkind = {
                    mainViewModel.fetchListByKind(it)
                }
            }
        }
    }
}




//        mainViewModel.foodList.observe(this) {
//            Log.d("AAA",it.toString())
//            tvFoundResults.text = "Found ${mainViewModel.foodList.value?.size}  results"
//            foodAdapter.submitList(it)
//        }

//        mainViewModel.fetchList()
//        mainViewModel.kindList.observe(this) {
//            val kindAdapter = KindAdapter(it)
//            recyclerViewKind.adapter = kindAdapter
//            kindAdapter.onItemClickkind = { Kind ->
//                mainViewModel.fetchListByKind(Kind)
//            }
//        }
//        mainViewModel.fetchKind()