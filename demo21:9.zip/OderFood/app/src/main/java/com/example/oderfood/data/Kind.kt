package com.example.oderfood.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity (tableName = "tb_kind")
data class Kind(
    @PrimaryKey (autoGenerate = true) val id: Int = 0,
    val kindFood: String?
)