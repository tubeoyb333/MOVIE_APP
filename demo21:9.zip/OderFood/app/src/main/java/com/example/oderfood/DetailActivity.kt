package com.example.oderfood

import android.annotation.SuppressLint
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import com.example.oderfood.data.Food

class DetailActivity : AppCompatActivity() {
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detail)
        val tvFoodName =findViewById<TextView>(R.id.tvFoodName)
        val tvFoodPice =findViewById<TextView>(R.id.tvFoodPrice)
        val imgFood = findViewById<ImageView>(R.id.imgFood)
        val btnBack = findViewById<Button>(R.id.btnBack);
        val food: Food = intent.getSerializableExtra("food") as Food
        Log.d("A","$food")
        tvFoodPice.text = food.price
        tvFoodName.text = food.name
        food.img?.let { imgFood.setBackgroundResource(it) }
        btnBack.setOnClickListener {
            finish()
        }
    }
}