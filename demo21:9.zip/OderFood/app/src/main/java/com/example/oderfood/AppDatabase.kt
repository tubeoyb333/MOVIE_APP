package com.example.oderfood

import androidx.room.Database
import androidx.room.RoomDatabase
import com.example.oderfood.data.Food
import com.example.oderfood.data.Kind

@Database(entities = [Food::class,Kind::class], version = 1)
abstract class AppDatabase: RoomDatabase() {
    abstract fun appDao():AppDAO
}