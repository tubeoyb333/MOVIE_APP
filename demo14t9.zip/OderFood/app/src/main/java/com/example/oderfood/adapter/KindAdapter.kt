package com.example.oderfood.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.oderfood.R
import com.example.oderfood.data.Kind

class KindAdapter(val listKind: List<Kind>?): RecyclerView.Adapter<KindAdapter.FoodKindViewHolder>()  {
    var onItemClickkind: (Kind)-> Unit={
    }
    inner class FoodKindViewHolder(viewKind: View):RecyclerView.ViewHolder(viewKind){
        val tvFoodKind = viewKind.findViewById<TextView>(R.id.tvFoodKind)
        init {
            tvFoodKind.setOnClickListener {
                onItemClickkind.invoke(listKind?.get(layoutPosition) ?: Kind(0,""))
            }
        }
        fun onBindKind(kind: Kind){
            tvFoodKind.text = kind.kindFood
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): FoodKindViewHolder {
        val inflater = LayoutInflater.from(parent.context)
        val viewKind = inflater.inflate(R.layout.item_kind,parent,false)
        return FoodKindViewHolder(viewKind)

    }

    override fun getItemCount(): Int {
        return listKind?.size ?: 0
    }

    override fun onBindViewHolder(holder: FoodKindViewHolder, position: Int) {
        holder.onBindKind(listKind?.get(position) ?: Kind(0,""))

    }

}
