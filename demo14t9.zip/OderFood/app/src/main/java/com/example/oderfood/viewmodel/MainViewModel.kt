package com.example.oderfood.viewmodel

import android.content.Context
import android.util.Log
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.room.Room
import com.example.oderfood.AppDAO
import com.example.oderfood.R
import com.example.oderfood.data.Food
import com.example.oderfood.data.Kind
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainViewModel(private val appDAO: AppDAO) : ViewModel() {
    val foodList: MutableLiveData<List<Food>?> = MutableLiveData()
    val kindList: MutableLiveData<List<Kind>?> = MutableLiveData()
    var currentList: MutableList<Food> = mutableListOf()
    var list: MutableList<Food> = mutableListOf(
        Food(1, "Veggie", "Veggie tomato mix", "N1,900", R.drawable.img),
        Food(2, "Egg", "Egg and cucmber...", "N1,900", R.drawable.img_2),
        Food(3, "Fried", "Fried chicken m.", "N1,900", R.drawable.img_3),
        Food(4, "Moi", "Moi-moi and ekpa.", "N1,900", R.drawable.img_4),
        Food(5, "Veggie", "Veggie tomato mix", "N1,900", R.drawable.img),
        Food(6, "Egg", "Egg and cucmber...", "N1,900", R.drawable.img_2),
        Food(7, "Fried", "Fried chicken m.", "N1,900", R.drawable.img_3),
        Food(8, "Moi", "Moi-moi and ekpa.", "N1,900", R.drawable.img_4),
        Food(9, "Veggie", "Veggie tomato mix", "N1,900", R.drawable.img),
        Food(10, "Egg", "Egg and cucmber...", "N1,900", R.drawable.img_2),
        Food(11, "Fried", "Fried chicken m.", "N1,900", R.drawable.img_3),
        Food(12, "Moi", "Moi-moi and ekpa.", "N1,900", R.drawable.img_4),
        Food(13, "Veggie", "Veggie tomato mix", "N1,900", R.drawable.img),
        Food(14, "Egg", "Egg and cucmber...", "N1,900", R.drawable.img_2),
        Food(15, "Fried", "Fried chicken m.", "N1,900", R.drawable.img_3),
        Food(16, "Moi", "Moi-moi and ekpa.", "N1,900", R.drawable.img_4),
        Food(17, "Veggie", "Veggie tomato mix", "N1,900", R.drawable.img),
        Food(18, "Egg", "Egg and cucmber...", "N1,900", R.drawable.img_2),
        Food(19, "Fried", "Fried chicken m.", "N1,900", R.drawable.img_3),
        Food(20, "Moi", "Moi-moi and ekpa.", "N1,900", R.drawable.img_4),
        Food(21, "Veggie", "Veggie tomato mix", "N1,900", R.drawable.img),
        Food(22, "Egg", "Egg and cucmber...", "N1,900", R.drawable.img_2),
        Food(23, "Fried", "Fried chicken m.", "N1,900", R.drawable.img_3),
        Food(24, "Moi", "Moi-moi and ekpa.", "N1,900", R.drawable.img_4)
    )
    val listKind: List<Kind> = listOf(
        Kind(kindFood = "All"),
        Kind(kindFood = "Veggie"),
        Kind(kindFood = "Fried"),
        Kind(kindFood = "Egg"),
        Kind(kindFood = "Moi")
    )

    fun insertFoodList() {
        viewModelScope.launch(Dispatchers.IO) {
            appDAO.insertFoodList(list)
            withContext(Dispatchers.Main){
                getFoodList()
            }
        }
    }

    fun getFoodList() {
        viewModelScope.launch(Dispatchers.IO) {
            val list = appDAO.getFoodList()
            withContext(Dispatchers.Main){
                foodList.value = list
                Log.d("TRANANHTU",list.toString())
            }
        }
    }
//    fun fetchList() {
//        currentList = list
//        foodList.value = list
//    }
//
//    fun fetchListByKind(kind: Kind) {
//        currentList = mutableListOf()
//        if (kind.kindFood == "All") {
//            currentList.addAll(list)
//        } else {
//            currentList.addAll(list.filter { it.kind == kind.kindFood })
//        }
//        foodList.value = currentList
//    }
//    fun deleteFood(food: Food) {
//        list.remove(food)
//        currentList.remove(food)
//        foodList.value = currentList
//    }
//    fun fetchKind() {
//        kindList.value = listKind
//    }
}
